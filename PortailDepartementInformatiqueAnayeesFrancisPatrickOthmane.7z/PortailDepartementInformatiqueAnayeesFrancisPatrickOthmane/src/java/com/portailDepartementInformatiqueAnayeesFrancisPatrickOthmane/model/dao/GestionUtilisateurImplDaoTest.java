/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.portailDepartementInformatiqueAnayeesFrancisPatrickOthmane.model.dao;

import com.portailDepartementInformatiqueAnayeesFrancisPatrickOthmane.model.entities.Administrateur;
import com.portailDepartementInformatiqueAnayeesFrancisPatrickOthmane.model.entities.Cours;
import com.portailDepartementInformatiqueAnayeesFrancisPatrickOthmane.model.entities.Etudiant;
import com.portailDepartementInformatiqueAnayeesFrancisPatrickOthmane.model.entities.NoteDeCours;
import com.portailDepartementInformatiqueAnayeesFrancisPatrickOthmane.model.entities.Notes;
import com.portailDepartementInformatiqueAnayeesFrancisPatrickOthmane.model.entities.Professeur;
import com.portailDepartementInformatiqueAnayeesFrancisPatrickOthmane.model.entities.Projet;
import com.portailDepartementInformatiqueAnayeesFrancisPatrickOthmane.model.entities.Visiteur;
import java.text.ParseException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author anayeesFrancisPatrickOthmane
 */
public class GestionUtilisateurImplDaoTest {

    public static void main(String[] args) throws ParseException {

//        testFindAllEtudiants();
//        testFindAllCours();
//        testFindAllProf();
//        testFindAllProjets();
//        testFindProjetById();
//        testFindAllNotesDeCours();
//        testFindAllVisiteurs();
//        testFindAllAdministrateurs();
//        testFindAllEtudiants();
//        testFindAllCours();
//        testFindAllProf();
//        testfindProfByProjectName();
//        testFindAllProjets();
//        testFindAllNotesDeCours();
//        testCreateNotes();
//        testFindNotesDeCoursByName();
//        testFindAllVisiteurs();
//        testFindAllAdministrateurs();
//        testFindNotesDeCoursById();
//        testProfById();
//        testFindEtudiantByRole();
//        testFindEtudiantByName();
//        testFindEtudiantById();
//        testCreateEtudiant();
//        testFindAllEtudiants();
//        testDeleteEtudiant();
//        testUpdateEtudiant();
//        testFindAllEtudiantsByDisponibilitéAndByRole();
//        testFindNotesDeCoursByName();
//        testCreateProf();
//        testUpdateProf();
//        testFindAllEtudiants();
//        testFindAllCours();
//        testFindAllProf();
//        testFindAllProjets();
//        testFindCoursById();
//        testFindAllNotesDeCours();
//        testFindAllVisiteurs();
//        testFindAllAdministrateurs();
//        testFindNotesDeCoursById();
//        testFindAllCoursByNomProfesseur();
//        testFindNotesDeCoursByCoursID();
//        testFindNotesDeCoursByAuthor();
//        testProfById();
//        testFindEtudiantByRole();
//        testFindEtudiantByName();
//        testFindEtudiantById();
//        testCreateEtudiant();
//        testDeleteEtudiant();
//        testFindAllEtudiants();
//        testUpdateEtudiant();
//        testFindProjetByName();
//        testCreateEtudiantProjet();
//        testCreateProjet();
//        testFindEtudiantsProjet();
//        testFindAllProjetsByNomPrenomProf();
    }

    public static void testFindAllEtudiants() {
        System.out.println("findAllEtudiants");
        GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
        List<Etudiant> result = instance.findAllEtudiants();
        System.out.println(result.get(0).afficherTitreDesColonnes());
        for (Etudiant utilisateur : result) {
            System.out.println(utilisateur.toString());
        }
    }

    public static void testFindAllProf() {
        System.out.println("findAllProfesseurs");
        GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
        List<Professeur> result = instance.findAllProfesseurs();
        System.out.println(result.get(0).afficherTitreDesColonnes());
        for (Professeur prof : result) {
            System.out.println(prof.toString());
        }
    }

    public static void testFindAllAdministrateurs() {
        System.out.println("findAllAdmins");
        GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
        List<Administrateur> result = instance.findAllAdmins();
        System.out.println(result.get(0).afficherTitreDesColonnes());
        for (Administrateur utilisateur : result) {
            System.out.println(utilisateur.toString());
        }
    }

    public static void testFindAllCours() {
        System.out.println("findAllCours");
        GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
        List<Cours> result = instance.findAllCours();
        System.out.println(result.get(0).afficherTitreDesColonnes());
        for (Cours cours : result) {
            System.out.println(cours.toString());
        }
    }

    public static void testFindAllProjets() {
        System.out.println("findAllProjets");
        GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
        List<Projet> result = instance.findAllProjets();
        System.out.println(result.get(0).afficherTitreDesColonnes());
        for (Projet projet : result) {
            System.out.println(projet.toString());
        }
    }

    public static void testFindProjetByName() {
        System.out.println("FindProjetByName");
        String nom = "";
        GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
        System.out.println("Entrez le nom du projet : ");
        Scanner lectureClavier = new Scanner(System.in);
        nom = lectureClavier.next();
        Projet result = instance.findProjetByName(nom);
        System.out.println(result.toString());

    }

    public static void testFindAllNotesDeCours() {
        System.out.println("findAllNotes");
        GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
        List<NoteDeCours> result = instance.findAllNotesDeCours();
        System.out.println(result.get(0).afficherTitreDesColonnes());
        for (NoteDeCours notes : result) {
            System.out.println(notes.toString());
        }
    }

    public static void testFindAllVisiteurs() {
        System.out.println("findAllVisiteurs");
        GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
        List<Visiteur> result = instance.findAllVisiteurs();
        System.out.println(result.get(0).afficherTitreDesColonnes());
        for (Visiteur visiteur : result) {
            System.out.println(visiteur.toString());
        }
    }

    public static void testFindNotesDeCoursById() {
        System.out.println("findNotesDeCoursById");
        int id = 0;
        GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
        System.out.println("Entrez l'id du note de cours : ");
        Scanner lectureClavier = new Scanner(System.in);
        id = lectureClavier.nextInt();
        NoteDeCours result = instance.findNotesDeCoursById(id);
        System.out.println(result.afficherTitreDesColonnes());
        System.out.println(result.toString());
    }

    public static void testFindEtudiantByName() {
        System.out.println("findByName");
        String nom = "";
        GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
        System.out.println("Entrez le nom de l'utilisateur : ");
        Scanner lectureClavier = new Scanner(System.in);
        nom = lectureClavier.next();
        Etudiant result = instance.findEtudiantByName(nom);
        System.out.println(result.toString());

    }

    public static void testFindEtudiantById() {
        System.out.println("findById");
        int id = 0;
        GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
        System.out.println("Entrez l'id de l'utilisateur : ");
        Scanner lectureClavier = new Scanner(System.in);
        id = lectureClavier.nextInt();
        Etudiant result = instance.findEtudiantById(id);
        System.out.println(result.toString());
    }

    public static void testFindEtudiantByRole() {
        System.out.println("findByRole");
        Scanner lectureClavier = new Scanner(System.in);
        GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
        System.out.println("Entrez le prénom de l'étudiant: ");
        String prenom = lectureClavier.nextLine();
        System.out.println("Entrez le nom de l'etudiant: ");
        String nom = lectureClavier.nextLine();
        System.out.println("Entrez le role de l'etudiant : ");
        String role = lectureClavier.next();
        Etudiant result = instance.findEtudiantByRole(prenom, nom, role);
        System.out.println(result.toString());

    }

//    public static void testCreateEtudiant() {
//        System.out.println("create");
//        Etudiant utilisateur = null;
//        GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
//        Scanner lectureClavier = new Scanner(System.in);
//        System.out.println("Entrez l'ID ");
//        int id = lectureClavier.nextInt();
//        System.out.println("Entrez email ");
//        String email = lectureClavier.next();
//        System.out.println("L'utilisateur est-il actif(oui/non)?");
//        String reponse = lectureClavier.next();
//        boolean active = reponse.equals("oui") ? true : false;
//
//        System.out.println("Entrez le nom ");
//        String nom = lectureClavier.next();
//        System.out.println("Entrez le prenom ");
//        String prenom = lectureClavier.next();
//        System.out.println("Entrez le nom de l'utilisateur");
//        String nomUtilisateur = lectureClavier.next();
//        System.out.println("Entrez le mot de passe");
//        String motDePasse = lectureClavier.next();
//        System.out.println("Entrez le profil");
//        String profil = lectureClavier.next();
//        System.out.println("Entrez la date de naissance (au format jj-mm-aaaa)");
//        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
//        Date ddn = null;
//        try {
//            java.util.Date date = sdf.parse(lectureClavier.next());
//            ddn = new java.sql.Date(date.getTime());
//        } catch (ParseException e) {
//            e.printStackTrace();
//        }
//        System.out.println("Entrez le role");
//        String role = lectureClavier.next();
//        System.out.println("L'utilisateur est-il actif(oui/non)?");
//        String reponse1 = lectureClavier.next();
//        boolean formation = reponse1.equals("oui") ? true : false;
//        System.out.println("Entrez l'ID du cours ");
//        int coursID = lectureClavier.nextInt();
//        System.out.println("L'utilisateur est-il disponible(oui/non)?");
//        String reponse3 = lectureClavier.next();
//        boolean dispo = reponse3.equals("oui") ? true : false;
//
//        utilisateur = new Etudiant(id, prenom, nom, email, profil, role, active, nomUtilisateur, motDePasse, ddn, formation, coursID, dispo);
//
//        boolean result = instance.createEtudiant(utilisateur);
//        if (result) {
//            System.out.println("insertion reussite");
//        } else {
//            System.out.println("insertion echec ");
//        }
//
//    }
//    public static void testUpdateEtudiant() {
//        System.out.println("updateEtudiant");
//        Etudiant etudiant = null;
//        GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
//        System.out.println("Entrez l'id de l'étudiant.e à mettre à jour: ");
//        Scanner lectureClavier = new Scanner(System.in);
//        int id = lectureClavier.nextInt();
//        etudiant = instance.findEtudiantById(id);
//        System.out.println("Entrez le prénom de l'étudiant.e: ");
//        String prenom = lectureClavier.next();
//        etudiant.setPrenom(prenom);
//        System.out.println("Entrez le nom de l'étudiant.e: ");
//        String nom = lectureClavier.next();
//        etudiant.setNom(nom);
//        System.out.println("Entrez le courriel de l'étudiant.e: ");
//        String email = lectureClavier.next();
//        etudiant.setEmail(email);
//        System.out.println("Entrez la date de naissance (au format jj-mm-aaaa)");
//        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
//        Date ddn = null;
//        try {
//            java.util.Date date = sdf.parse(lectureClavier.next());
//            ddn = new java.sql.Date(date.getTime());
//        } catch (ParseException e) {
//            e.printStackTrace();
//        }
//        etudiant.setDdn(ddn);
//        System.out.println("L'étudiant est-il actif (oui/non)? ");
//        String reponse = lectureClavier.next();
//        boolean active = reponse.equals("oui") ? true : false;
//        etudiant.setActive(active);
//        System.out.println("Entrez le rôle de l'étudiant.e (Étudiant/Tuteur/Tutoré):");
//        String role = lectureClavier.next();
//        etudiant.setRole(role);
//        System.out.println("L'étudiant a-t'il complété sa formation (oui/non)? ");
//        String reponseFormation = lectureClavier.next();
//        boolean formationCompletee = reponseFormation.equals("oui") ? true : false;
//        etudiant.setFormationCompletee(formationCompletee);
//        System.out.println("Entrez le profil de l'étudiant.e (Programmation/Réseautique): ");
//        String profil = lectureClavier.next();
//        etudiant.setProfil(profil);
//        System.out.println("Entrez le nom d'utilisateur: ");
//        String nomUtilisateur = lectureClavier.next();
//        etudiant.setNomUtilisateur(nomUtilisateur);
//        System.out.println("Entrez le mot de passe: ");
//        String motDePasse = lectureClavier.next();
//        etudiant.setMotDePasse(motDePasse);
//        System.out.println("Entrez l'ID du cours ");
//        int coursID = lectureClavier.nextInt();
//        etudiant.setCoursId(coursID);
//        System.out.println("L'utilisateur est-il disponible(oui/non)?");
//        String reponse3 = lectureClavier.next();
//        boolean dispo = reponse3.equals("oui") ? true : false;
//        etudiant.setDispoTutorat(dispo);
//        boolean result = instance.updateEtudiant(etudiant);
//        if (result) {
//            System.out.println(String.format("L'étudiant.e %s %s a été mis à jour dans la base de données", etudiant.getPrenom(), etudiant.getNom()));
//        } else {
//            System.out.println("L'étudiant.e dont l'id est " + id + " n'existe pas dans la base de données");
//        }
//    }
    public static void testDeleteEtudiant() {
        System.out.println("deleteEtudiant");
        int id = 0;
        GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
        System.out.println("Entrez l'id de l'utilisateur : ");
        Scanner lectureClavier = new Scanner(System.in);
        id = lectureClavier.nextInt();
        boolean result = instance.deleteEtudiant(id);
        if (result != false) {
            System.out.println("l'utilisateur dont l'id est " + id + " est supprimé de la base des données");
        } else {
            System.out.println("l'utilisateur dont l'id est " + id + " n'existe pas dans la base des données");
        }
    }

    public static void testProfById() {
        System.out.println("findProfesseurById");
        int id = 0;
        GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
        System.out.println("Entrez l'id du professeur : ");
        Scanner lectureClavier = new Scanner(System.in);
        id = lectureClavier.nextInt();
        Professeur result = instance.findProfById(id);
        System.out.println(result.toString());

    }

    public static void testfindProfByProjectName() {

        System.out.println("findProfByProjectName");
        String nomProjet = "";
        GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
        System.out.println("Entrez le nom du projet : ");

        Scanner lectureClavier = new Scanner(System.in);
        nomProjet = lectureClavier.next();
        Professeur expResult = null;
        Professeur result = instance.findProfByProjectName(nomProjet);
        System.out.println(result.toString());

    }

    public static void testFindCoursById() {
        System.out.println("findCoursById");
        int id = 0;
        GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
        System.out.println("Entrez l'id du cours : ");
        Scanner lectureClavier = new Scanner(System.in);
        id = lectureClavier.nextInt();
        Cours result = (Cours) instance.findCoursById(id);
        System.out.println(result.afficherTitreDesColonnes());
        System.out.println(result.toString());
    }

//    public static void testCreateProf() {
//        System.out.println("createProf");
//        Professeur utilisateur = null;
//        GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
//        Scanner lectureClavier = new Scanner(System.in);
////        System.out.println("Entrez le ID du professeur: ");
////        int id = lectureClavier.nextInt();
//        System.out.println("Entrez le prénom du professeur: ");
//        String prenom = lectureClavier.next();
//        System.out.println("Entrez le nom du professeur: ");
//        String nom = lectureClavier.next();
//        System.out.println("Entrez le courriel du professeur: ");
//        String courriel = lectureClavier.next();
////        System.out.println("Entrez le rôle du professeur (Professeur): ");
////        String role = lectureClavier.next();
//        String role = "Professeur";
//        System.out.println("Le professeur est-il actif (oui/non)? ");
//        String reponse = lectureClavier.next();
//        boolean active = reponse.equals("oui") ? true : false;
//        System.out.println("Entrez le nom d'utilisateur: ");
//        String nomUtilisateur = lectureClavier.next();
//        System.out.println("Entrez le mot de passe: ");
//        String motDePasse = lectureClavier.next();
//        utilisateur = new Professeur(prenom, nom, courriel, role, active, nomUtilisateur, motDePasse);
//
//        boolean result = instance.createProf(utilisateur);
//        if (result) {
//            System.out.println("insertion reussite");
//        } else {
//            System.out.println("insertion echec ");
//        }
//    }
    public static void testUpdateProf() {
        System.out.println("updateProf");
        Professeur utilisateur = null;
        GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
        Scanner lectureClavier = new Scanner(System.in);
        System.out.println("");
        boolean result = instance.updateProf(utilisateur);
    }

    public static void testFindAllEtudiantsByDisponibilitéAndByRole() {
        System.out.println("findAllEtudiantsByDisponibilitéAndByRole");
        GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
        Scanner lectureClavier = new Scanner(System.in);
        System.out.println("L'étudiant est-il disponible (oui/non)? ");
        String reponse = lectureClavier.next();
        boolean disponible = reponse.equals("oui") ? true : false;
        System.out.println("Entrez le rôle de l'étudiant (Tuteur/Tutore): ");
        String role = lectureClavier.next();
        List<Etudiant> result = instance.findAllEtudiantsByDisponibilitéAndByRole(role, disponible);
        System.out.println(result.toString());
    }

    public static void testFindProjetById() {
        System.out.println("findProjetById");
        int id = 0;
        GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
        System.out.println("Entrez l'id du projet : ");
        Scanner lectureClavier = new Scanner(System.in);
        id = lectureClavier.nextInt();
        Projet result = instance.findProjetById(id);
        System.out.println(result.toString());

    }

    public static void testFindNotesDeCoursByName() {
        System.out.println("findNotesDeCoursByName");
        Scanner lectureClavier = new Scanner(System.in);
        GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
        System.out.println("Entrez le nom du note de cours: ");
        String nom = lectureClavier.nextLine();
        try {
            NoteDeCours result = instance.findNotesDeCoursByName(nom);
            System.out.println(result.toString());
        } catch (Exception e) {
            System.out.println("Aucune note de cours trouvée.");
        }

    }

    public static void testFindAllCoursByNomProfesseur() {
        System.out.println("findAllCoursByNomProfesseur");
        try {

            Scanner lectureClavier = new Scanner(System.in);
            System.out.println("Entrez le nom du professeur: ");
            String nomProfesseur = lectureClavier.next();
            GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
            List<Cours> expResult = null;
            List<Cours> result = instance.findAllCoursByNomProfesseur(nomProfesseur);
            System.out.println(result.get(0).afficherTitreDesColonnes());
            for (Cours cours : result) {
                System.out.println(cours.toString());
            }
        } catch (IndexOutOfBoundsException e) {
            System.out.println("Erreur: Le nom du professeur n'existe pas.");
        }
    }

    public static void testFindNotesDeCoursByCoursID() {
        System.out.println("findNotesDeCoursByCoursID");
        try {
            Scanner lectureClavier = new Scanner(System.in);
            System.out.println("Entrez l'id du cours: ");
            int coursID = lectureClavier.nextInt();
            GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
            List<NoteDeCours> expResult = null;
            List<NoteDeCours> result = instance.findNotesDeCoursByCoursID(coursID);
            System.out.println(result.get(0).afficherTitreDesColonnes());
            for (NoteDeCours noteDeCours : result) {
                System.out.println(noteDeCours.toString());
            }
        } catch (IndexOutOfBoundsException e) {
            System.out.println("Erreur: L'id du cours n'existe pas.");
        }
    }

    public static void testFindNotesDeCoursByAuthor() {
        System.out.println("findNotesDeCoursByAuthor");
        try {
            Scanner lectureClavier = new Scanner(System.in);
            System.out.println("Entrez le nom de l'auteur/professeur: ");
            String professeurAuteur = lectureClavier.next();
            GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
            List<NoteDeCours> expResult = null;
            NoteDeCours result = instance.findNotesDeCoursByName(professeurAuteur);
            System.out.println(result.afficherTitreDesColonnes());

            System.out.println(result.toString());

        } catch (Exception e) {
            System.out.println("Erreur: Le nom du professeur n'existe pas.");
        }
    }

    public static void testFindEtudiantsProjet() {
        System.out.println("testFindEtudiantsProjet");
        try {
            Scanner lectureClavier = new Scanner(System.in);
            System.out.println("Entrez le nom du projet ");
            String nomProjet = lectureClavier.next();
            GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
            List<Etudiant> result = instance.findEtudiantsParProjet(nomProjet);

            for (Etudiant etudiant : result) {
                System.out.println(etudiant.toString());
            }

        } catch (Exception e) {
            System.out.println("Erreur: Le nom du professeur n'existe pas.");
        }
    }

    public static void testCreateNotes() {
        System.out.println("createNotes");
        NoteDeCours notes = null;
        GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
        Scanner lectureClavier = new Scanner(System.in);
//        System.out.println("Entrez le ID du professeur: ");
//        int id = lectureClavier.nextInt();
        System.out.println("Entrez le lien du cours: ");
        String Lien = lectureClavier.next();
        System.out.println("Entrez le nom du cours: ");
        String nom = lectureClavier.next();
        System.out.println("Entrez le coursId : ");
        int coursId = lectureClavier.nextInt();

//        notes = new NoteDeCours(Lien, coursId, nom);
//
//        boolean result = instance.createNotesDeCours(notes);
//        if (result) {
//            System.out.println("insertion reussite");
//        } else {
//            System.out.println("insertion echec ");
//        }
    }

    public static void testCreateEtudiantProjet() {
        System.out.println("create role");
        Etudiant etudiant = null;
        //  Role role = null;
        GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();

        Scanner lectureClavier = new Scanner(System.in);
        System.out.println("Entrez le DA");
        int id = lectureClavier.nextInt();

        System.out.println("Choisir entre admin, vendeur, editeur, expediteur et assistant");
        String projetEtudiant = lectureClavier.next();
        String projetEtud = projetEtudiant.toLowerCase();

        boolean result = instance.createEtudiantProjet(id, projetEtud);
        if (result) {
            System.out.println("L'utilisateur est mis à jour ");
        } else {
            System.out.println("Echec de mis à jour ");
        }
    }

    public static void testCreateProjet() {
        System.out.println("createProjet");
        Projet projet = null;
        Scanner sc = new Scanner(System.in);

        System.out.println("Entrez le nom du projet: ");
        String nomProjet = "Pendu";

        System.out.println("Entrez l'année du projet: ");
        int annee = 2023;

        System.out.println("Entrez la description du projet: ");
        String description = "Jeu de Pendu";

        System.out.println("Entrez le id du professeur: ");
        Professeur prof = new Professeur();
        prof.setId(1);

//        System.out.println("Entrez la note: ");
//        Notes note = new Notes();
//        note.setId(3);
        System.out.println("Entrez le cours: ");
        Cours cours = new Cours();
        cours.setId(2);

        System.out.println("Entrez video: ");
        String video = "www.video.com";

        System.out.println("Entrez lienGit");
        String git = "www.gitlab.com";

        GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();

        projet = new Projet(nomProjet, annee, description, video, git, cours, prof);
        boolean expResult = false;
        boolean result = instance.createProjet(projet);

        if (result) {
            System.out.println("Le projet a été ajouté");
        } else {
            System.out.println("Echec de mis à jour ");
        }

    }

    public static void testFindAllProjetsByNomPrenomProf() {
        System.out.println("findAllProjetsByNomPrenomProf");
        try {

            String nomProf = "";
            System.out.println("Entrez le nom du prof: ");
            Scanner sc = new Scanner(System.in);
            nomProf = sc.next();

            GestionUtilisateurImplDao instance = new GestionUtilisateurImplDao();
            List<Projet> expResult = null;
            List<Projet> result = instance.findAllProjetsByNomPrenomProf(nomProf);

            for (Projet projet : result) {
                System.out.println(projet.toString());
            }
        } catch (Exception e) {
            System.out.println("Le nom du prof n'existe pas");
        }

    }
}
